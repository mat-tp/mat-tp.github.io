# My Website

This is a simple website created for demonstration purposes.

## File Structure
- **templates/**: Contains HTML files.
- **static/**: Contains CSS and JavaScript files.

